// Component removed in favor of Discovery.tsx
export {};